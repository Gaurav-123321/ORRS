package com.rms.payment.service;

import com.rms.payment.entity.Payment;

public interface PaymentService {
    Payment processPayment(Long userId, Long bookingId, Double amount);
}
