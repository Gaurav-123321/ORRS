package com.rms.payment.service;

import com.rms.payment.entity.Payment;
import com.rms.payment.repository.PaymentRepository;
import com.rms.payment.feign.BookingServiceClient;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class PaymentServiceImpl implements PaymentService {
    private final PaymentRepository paymentRepository;
    private final BookingServiceClient bookingServiceClient;

    public PaymentServiceImpl(PaymentRepository paymentRepository, BookingServiceClient bookingServiceClient) {
        this.paymentRepository = paymentRepository;
        this.bookingServiceClient = bookingServiceClient;
    }

    @Override
    public Payment processPayment(Long userId, Long bookingId, Double amount) {
        Payment payment = new Payment();
        payment.setUserId(userId);
        payment.setBookingId(bookingId);
        payment.setAmount(amount);
        payment.setStatus("SUCCESS");
        payment.setPaymentDate(LocalDateTime.now());

        Payment savedPayment = paymentRepository.save(payment);

        bookingServiceClient.updateBookingStatus(bookingId, "PAID");

        return savedPayment;
    }
}
