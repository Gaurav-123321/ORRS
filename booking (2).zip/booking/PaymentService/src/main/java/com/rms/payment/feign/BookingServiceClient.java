package com.rms.payment.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "BOOKING-SERVICE")
public interface BookingServiceClient {
    @PutMapping("/bookings/update-status/{bookingId}/{status}")
    void updateBookingStatus(@PathVariable Long bookingId, @PathVariable String status);
}
