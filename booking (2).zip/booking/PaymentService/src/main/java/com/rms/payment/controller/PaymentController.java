package com.rms.payment.controller;

import com.rms.payment.entity.Payment;
import com.rms.payment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
public class PaymentController {
    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/process")
    public ResponseEntity<Payment> processPayment(
            @RequestParam Long userId, 
            @RequestParam Long bookingId, 
            @RequestParam Double amount) {
        Payment payment = paymentService.processPayment(userId, bookingId, amount);
        return ResponseEntity.ok(payment);
    }
}
